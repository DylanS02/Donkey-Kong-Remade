Unity 3D Project Template 2020.3
This project template for all Unity 2020.3 projects in MI 231 - Interactive Media and Game Development includes:

A Unity project template that includes the correct .gitignore and .gitattributes files to work with GitLab.MSU.edu. You won't see the .git___ files because they are invisible, but they help GIT work well with Unity projects.

This README.md MarkDown file. You will need to edit the Required ReadMe Info section below for EVERY project in this class.
A UnityWindowLayout.wlt file in the project folder (the same folder as this ReadMe.md file) that you can load to lay out the Unity window the way that Jeremy recommends.
Modifications to the base Unity project that remove Plastic SCM, which is extremely helpful for allowing Git to work well.

           I hope this template works for you. If it doesn't, please let us know on Piazza. – Jeremy


Required ReadMe Info for ALL MI 231 Projects


Project   - Classic Game Donkey Kong

Your Name - Dylan Sadowski

Date      - March 27 2024




What are the controls to your game? How do we play?
Use WASD to move Dray around, space bar to jump, w to climb ladders




What creative additions did you make? How can we find them?
Made game




Any assets used that you didn't create yourself?  (art, music, etc. Just tell us where you got it, link it here)
No




Did you receive help from anyone outside this class?  (list their names and what they helped with)
No




Did you get help from any AI Code Assistants?  (Tell us which .cs file to look in for the citation and describe what you learned)
ChatGPT to help guide me through code - nothing specific




Did you get help from any online websites, videos, or tutorials?  (link them here)
https://youtu.be/8qciEnDt-n8?si=2t_Ta55vPdqDTmFF
Used mainly as a guide with layering objects to move and interact with, alongside setting up the game. Made a lot more additions and code to make it different




What trouble did you have with this project?
Making barrels roll down ladder




Is there anything else we should know?
No

